#!/bin/bash
date >> /timestamps.txt
