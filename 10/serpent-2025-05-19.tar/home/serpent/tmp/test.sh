echo `date` >> output.unl
