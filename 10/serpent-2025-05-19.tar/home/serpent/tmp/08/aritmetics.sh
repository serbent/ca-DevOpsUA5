#!/bin/bash



read -p "Enter the first integer: " A
read -p "Enter the second integer: " B

let sum=A+B

echo "The sum on integers is: $sum"
