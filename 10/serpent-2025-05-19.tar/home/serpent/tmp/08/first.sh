#!/bin/bash

NAME='Andrius'
SURNAME='Solovej'



read -p "Enter your name: " NAME

echo "Hello $NAME $SURNAME"
