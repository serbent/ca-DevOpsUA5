#!/bin/bash


DATE=$(date)
DATE_NOW=`date`
echo $DATE
sleep 5
echo $DATE_NOW
sleep 5
echo $DATE_NOW
